package com.smechain.state;

import java.util.HashMap;
import java.util.Map;

public class State {
    public Map<String, InvoiceRecord> invoices = new HashMap<>();

    // SMEUSD is the internal USD-backed settlement balance.
    // Amounts are stored in cents to avoid floating point errors.
    public Map<String, Long> smeUsdBalancesCents = new HashMap<>();

    // Tracks mint/redeem/transfer references for audit and idempotency.
    public Map<String, String> settlementReferences = new HashMap<>();
}
