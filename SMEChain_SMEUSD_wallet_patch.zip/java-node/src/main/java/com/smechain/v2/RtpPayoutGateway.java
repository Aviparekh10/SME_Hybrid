package com.smechain.v2;

public interface RtpPayoutGateway {
    RtpPayoutReceipt sendPayout(String destinationAccountRef, long amountCents, String memo);
}
