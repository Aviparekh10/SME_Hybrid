package com.smechain.v2;

public class RtpPayoutReceipt {
    public String rail;
    public String status;
    public String providerReference;
    public long amountCents;
    public String destinationAccountRef;

    public RtpPayoutReceipt() {}

    public RtpPayoutReceipt(String rail, String status, String providerReference, long amountCents, String destinationAccountRef) {
        this.rail = rail;
        this.status = status;
        this.providerReference = providerReference;
        this.amountCents = amountCents;
        this.destinationAccountRef = destinationAccountRef;
    }
}
