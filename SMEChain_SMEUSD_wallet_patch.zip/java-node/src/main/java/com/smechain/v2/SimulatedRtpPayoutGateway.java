package com.smechain.v2;

import java.util.UUID;

public class SimulatedRtpPayoutGateway implements RtpPayoutGateway {
    @Override
    public RtpPayoutReceipt sendPayout(String destinationAccountRef, long amountCents, String memo) {
        return new RtpPayoutReceipt(
                "RTP",
                "CONFIRMED",
                "rtp_sim_" + UUID.randomUUID(),
                amountCents,
                destinationAccountRef
        );
    }
}
