package com.smechain.v2;

public enum SettlementRail {
    RTP,
    FEDNOW,
    ACH,
    SWIFT,
    INTERNAL_WALLET
}
