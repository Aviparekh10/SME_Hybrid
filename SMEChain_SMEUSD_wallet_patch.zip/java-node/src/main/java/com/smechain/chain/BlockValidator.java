package com.smechain.chain;

import com.smechain.state.State;
import com.smechain.state.StateMachine;
import com.smechain.state.StateTransitionException;

import java.util.List;
import java.util.stream.Collectors;

public final class BlockValidator {
    private BlockValidator(){}

    private static final java.util.concurrent.ConcurrentHashMap<String, Boolean> identityWhitelist = new java.util.concurrent.ConcurrentHashMap<>();
   
    public static void updateIdentityStatus(String addressHash, boolean isApproved) {
        identityWhitelist.put(addressHash, isApproved);
    }

    public static void validateBlock(Block prev, Block b, long expectedHeight, State stateForPrev) throws StateTransitionException {
        if (b.height != expectedHeight) throw new StateTransitionException("bad height");
        if (prev == null) {
            if (!b.header.prevHash.equals("0".repeat(64))) throw new StateTransitionException("genesis prev hash invalid");
        } else {
            if (!b.header.prevHash.equals(prev.blockHash)) throw new StateTransitionException("prev hash mismatch");
        }

        String hash = b.header.headerHash();
        if (!hash.equals(b.blockHash)) throw new StateTransitionException("blockHash mismatch");
        if (!b.header.meetsDifficulty(b.blockHash)) throw new StateTransitionException("PoW not satisfied");

        List<String> txids = b.transactions.stream().map(t -> t.txId).collect(Collectors.toList());
        String merkle = Merkle.merkleRoot(txids);
        if (!merkle.equals(b.header.merkleRoot)) throw new StateTransitionException("bad merkle root");

        // Validate txs and apply to state
        State tmp = cloneState(stateForPrev);
        for (Transaction tx : b.transactions) {
            // 1. Verify cryptography first
            if (tx.signatureB64 == null || !tx.verifySignature()) throw new StateTransitionException("invalid tx signature");
            
            // 2. INSERTED FOR INDUSTRY-GRADE COMPLIANCE (Fast in-memory check)
            // This prevents un-KYC'd or blocked addresses from submitting payments without hitting a slow network API
            if (!identityWhitelist.isEmpty() && !identityWhitelist.getOrDefault(tx.senderBusinessId(), false)) {
                throw new StateTransitionException("Compliance rejection: Sender " + tx.senderBusinessId() + " is not authorized in identity whitelist");
            }

            // 3. Apply changes if all checks pass
            StateMachine.apply(tmp, tx);
        }
    }

    private static State cloneState(State st) {
        // Shallow clone: InvoiceRecords are replaced by deterministic transitions in this v1.
        // For strictness you'd deep copy.
        State s = new State();
        s.invoices.putAll(st.invoices);
        s.smeUsdBalancesCents.putAll(st.smeUsdBalancesCents);
        s.settlementReferences.putAll(st.settlementReferences);
        return s;
    }
}